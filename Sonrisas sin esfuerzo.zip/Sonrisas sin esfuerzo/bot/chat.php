<?php
include "Bot.php";
$bot = new Bot;
$questions = [
    "cual es el horario?" => "9:00 AM - 8:00 PM (L-V) 9:00 AM - 2:00 PM (S).",

    "a que hora cierran?" => "9:00 AM - 8:00 PM (L-V) 9:00 AM - 2:00 PM (S).",

    "que dias trabajan?" => "9:00 AM - 8:00 PM (L-V) 9:00 AM - 2:00 PM (S).",

    "recomendaciones antes de una cita" =>"Una buena manera de prepararse para la cita con el dentista: 1. Lavarse los dientes, 2.  Acudir a la cita con antelación, 3. Evitar el tabaco, 4. Acudir antes de tener molestias, 5. Busca un dentista cerca, Ve acompañado. Con estas recomendaciones tendras una vicita mas placentera.",

    "Como cancelar mi cita" =>"Inicia sesión, ve a citas y desde ahi podras cancelar o ponte en contacto con tu médico al 33-36-38-36-24.",

    "a que edad hay que acudir al dentista?" =>"Se recomienda visitar al dentista por primera vez al completarse la primera dentición, en torno a los dos años y medio o tres. No obstante, puede hacerse también al cumplir un año o con la erupción de los primeros dientes. Y, por supuesto, ante cualquier problema que surja en esos primeros dientes o en la erupción de los mismos. Además, esa primera visita al odontólogo resulta muy útil como toma de contacto con el odontólogo, para crear confianza, con el fin de evitar futuros miedos o temores que surgen en algunos pacientes o niños, sobre todo cuando su primera visita es directamente para un tratamiento, como el empaste de una caries.",
    
      "cada cuanto tiempo se debe visitar al dentista?" => "Acudir al dentista periódicamente ayuda a detectar problemas a tiempo y evitar tratamientos tardíos y de urgencia. Aunque no se sientan molestias ni dolores, hay trastornos asintomáticos o que se sienten en fases avanzadas. Además, las necesidades de ortodoncia muchas veces no se perciben a simple vista. Así, las revisiones periódicas son una medida de prevención. La periodicidad de las visitas depende de la edad y el estado de su dentadura. Suelen oscilar entre seis meses y un año.",

      "cuantas veces hay que cepillarse los dientes?" => "Lo ideal es lavarse los dientes después de cada comida. Si no es posible, por lo menos debe realizarse el cepillado dental dos veces al día, y siempre por la noche antes de dormir. También es importante el tiempo dedicado a lavarse los dientes y el método. Se recomienda que el cepillado dure en torno a dos o tres minutos. La mejor técnica es con un cepillo suave colocado en ángulo de 45 º, con movimientos cortos adelante y atrás y circulares, cubriendo por completo los dientes. Siempre hay que cepillar los dientes por dentro, por fuera y por la zona de masticación. Se debe cambiar el cepillo cada tres o cuatro meses.",

      "para que sirven los enjuagues bucales?" => "Los colutorios son un complemento de la higiene bucodental. Pero nunca deben sustituir al cepillado. Suelen ayudar a reforzar el esmalte, reducir la sensibilidad dental, eliminar bacterias y combatir el mal aliento. Por ello, su uso es más recomendable en pacientes con halitosis, mayor propensión a caries por problemas en el esmalte dental, gingivitis o periodontitis.",

    "cuando hay que utilizar hilo dental?" => "La seda y el hilo dental ayudan en la higiene interproximal. Su uso elimina la placa dental o los restos de alimentos que quedan en los espacios interdentales, además del margen entre el diente y la encía. Se debe usar al menos una vez al día. El cepillo interdental también ayuda a limpiar las áreas entre los dientes. Puede resultar más útil en los casos en los que los espacios entre los dientes son grandes. Así que el uso de uno u otro dispositivo depende de la dentadura y los problemas de cada paciente. Debe ser el dentista el que aconseje a cada persona cuál emplear. También son muy útiles los irrigadores bucales como complemento al cepillado.",

    "como agendo una cita?" => "Registrate o inicia sesión, posteriormente encontraras la pestaña de agendar una cita, tambien puedes ponerte en contacto y solicitar la cita al 33-36-38-36-24.",

    "como modifico una cita?" => "Inicia sesión, posteriormente encontraras la pestaña de citas y podras modificar la fecha y hora, tambien puedes ponerte en contacto y solicitar el cambio al 33-36-38-36-24.",

    "recomendaciones despues de una limpieza?" => "Dado que acaba de limpiar y pulir sus dientes profesionalmente, querrá tener cuidado con los alimentos y bebidas que consume después de su cita. A veces, las limpiezas dentales pueden hacer que su dientes y encías para ser sensibles. Si ha recibido un tratamiento con flúor, querrá darle al flúor la oportunidad de adherirse a sus dientes. También puede preguntarle a su dentista o higienista cuáles son sus pautas posteriores a la limpieza.",

    "recomendaciones despues de una extraccion?" => "No escupa. Utilice un pañuelo para limpiar su boca según sea necesario, o trague su saliva, no utilice una pajilla de beber beba directo de la taza, no fume, mantenga sus dedos y su lengua lejos del área quirúrgica, siempre siga las instrucciones que le asigno su médico.",

    "donde se encuentra ubicada la clinica?" => "Av. Belisario Domínguez 1939, Monumental, 44320 Guadalajara, Jal.",

    "cual es la ubicacion?" => "Av. Belisario Domínguez 1939, Monumental, 44320 Guadalajara, Jal.",

    "donde se encuentran?" => "Av. Belisario Domínguez 1939, Monumental, 44320 Guadalajara, Jal.",

    "como los puedo contactar?" => "Tenemos distintos medios de contacto: 33-36-38-36-24, 33-18-50-41-55, clinicadentalbarba en instagram, irmabarba71@hotmail.com",
    
    "medios de contacto" => "Tenemos distintos medios de contacto: 33-36-38-36-24, 33-18-50-41-55, clinicadentalbarba en instagram, irmabarba71@hotmail.com",

    "donde los puedo contactar?" => "Tenemos distintos medios de contacto: 33-36-38-36-24, 33-18-50-41-55, clinicadentalbarba en instagram, irmabarba71@hotmail.com",

    "telefono" => "Tenemos distintos medios de contacto: 33-36-38-36-24, 33-18-50-41-55.",

    "donde los puedo contactar" => "Tenemos distintos medios de contacto: 33-36-38-36-24, 33-18-50-41-55, clinicadentalbarba en instagram, irmabarba71@hotmail.com",

    "formas de pago" => "Tenemos distintos medios de pago: Efectivo, pago con tarjeta de debito y credito y transferencia bancaria.",

    "metodos de pago" => "Tenemos distintos medios de pago: Efectivo, pago con tarjeta de debito y credito y transferencia bancaria.",

    "pago" => "Tenemos distintos medios de pago: Efectivo, pago con tarjeta de debito y credito y transferencia bancaria.",

    "caunto dura una cita" => "No puedo darte un tiempo, cada procedimiento tiene un proceso distinto y cada paciente es distinto, para mas información ponte en contacto con uno de nuestros médicos: 33-36-38-36-24.",

    "tratamientos" => "Ofrecemos una gran gama de tratamiento ya que contamos con distintos especialistas: Diagnóstico, ortodoncia, implantes, odontopediatra, esteticadental, periodoncia, prótesis, caries, endodoncia, carillas, bruxismo, halitosis.",

    "que tratamientos tienen?" => "Ofrecemos una gran gama de tratamiento ya que contamos con distintos especialistas: Diagnóstico, ortodoncia, implantes, odontopediatra, esteticadental, periodoncia, prótesis, caries, endodoncia, carillas, bruxismo, halitosis.",
       
    //name
    "como te llamas?" =>"Soy DentalBot y estoy para servirte.",
    "cual es tu nombre?" =>"Soy DentalBot y estoy para servirte.",
    "tienes nombre?" =>"Soy DentalBot y estoy para servirte.",


    //saludo
    "hola" =>"Hola que tal!",
    "un saludo" =>"Como te va.",
    "hello" =>"Un gusto de verte.",
 
    //despedida
    "gracias" =>"Estoy para servirte",
    "adios" =>"Hasta luego",
    "hasta la proxima" =>"Nos vemos pronto.",
    "nos vemos" =>"Te estare esperando.",
    "bye" =>"Good bye ♥",
    "see you" =>"See you lader ♥",
    //
    "what is your name?" =>" my name is DentalBot.",
   


    "tu nombre es?" => "Mi nombre es " . $bot->getName(),
    "tu eres?" => "Yo soy una " . $bot->getGender()
    
];

if (isset($_GET['msg'])) {
   
    $msg = strtolower($_GET['msg']);
    $bot->hears($msg, function (Bot $botty) {
        global $msg;
        global $questions;
        if ($msg == 'hi' || $msg == "hello") {
            $botty->reply('Hola');
        } elseif ($botty->ask($msg, $questions) == "") {
            $botty->reply("Lo siento, no puedo responder esa duda, ponte en contacto con tu médico al 33-36-38-36-24 o 33-18-50-41-55");
        } else {
            $botty->reply($botty->ask($msg,$questions));
        }
    });
}