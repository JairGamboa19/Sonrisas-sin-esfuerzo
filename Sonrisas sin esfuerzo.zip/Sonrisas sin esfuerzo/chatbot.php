<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatBot</title>
    <link rel="stylesheet" href="css/chatbot.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/tooplate-style.css">


</head>

<body>
<!-- HEADER -->
     <header>
          <div class="container">
               <div class="row">

                    <div class="col-md-4 col-sm-5">
                         <p>Bienvenidos a la clinica DentalBarba</p>
                    </div>
                         
                    <div class="col-md-8 col-sm-7 text-align-right">
                         <span class="phone-icon"><i class="fa fa-phone"></i>33-36-38-36-24</span>
                         <span class="date-icon"><i class="fa fa-calendar-plus-o"></i> 9:00 AM - 8:00 PM (L-V) 9:00 AM - 2:00 PM (S)</span>
                         <span class="email-icon"><i class="fa fa-envelope-o"></i> <a href="#">irmabarba71@hotmail.com</a></span>
                    </div>

               </div>
          </div>
     </header>


     <!-- MENU -->
     <section class="navbar navbar-default navbar-static-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="index.html" class="navbar-brand" style="font-size: 2.6em" ></i>DentalBarba</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                         <li><a href="index.html" class="smoothScroll">Inicio</a></li>
                         <li><a href="index.html" class="smoothScroll">Nosotros</a></li>
                         <li><a href="index.html" class="smoothScroll">Médicos</a></li>
                         <li><a href="index.html" class="smoothScroll">Noticias</a></li>
                         <li><a href="index.html" class="smoothScroll">Contacto</a></li>
                         <li><a href="chatbot.php" class="smoothScroll">ChatBot</a></li>
                         <li class="appointment-btn"><a href="hms/user-login.php">Paciente</a></li>
                         <li class="appointment-btn"><a href="hms/doctor/index.php">Médico</a></li>
                         <li class="appointment-btn"><a href="hms/admin/index.php">Administrador</a></li>
                    </ul>
               </div>
<div class="container">
       
            <div class="chatbox">
                        <h4> <img src='images/dentista.png' class='imgRedonda'/> Asistente </h4>
                             
                    
                        <div class="body" id="chatbody">
                        <p class="alicia">Hola! soy DentalBot. Estoy para responder tus dudas. Espero poder ayudarte.</p>
                            <div class="scroller"></div>
                        </div>

                    <form class="chat" method="post" autocomplete="off">
                    
                                <div>
                                    <input type="text" name="chat" id="chat" placeholder="Mensaje" style=" font-family: cursive; font-size: 20px;">
                                </div>
                                <div>
                                    <input type="submit" value="Enviar" id="btn">
                                </div>
                    </form>

        </div>
    </div>
    
    <script src="app.js"></script>
          </div>
     </section>
</body>

</html>